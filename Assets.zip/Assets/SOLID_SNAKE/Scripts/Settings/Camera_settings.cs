using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(menuName = "CameraSettings", fileName = "Camera/SettingsData")]

public class Camera_settings : ScriptableObject
{
    [SerializeField]private Vector3 offset;
    [SerializeField]private float follow_speed;

    public Vector3 Offset{get{return offset;}}
    public float FollowSpeed{get{return follow_speed;}}
}
