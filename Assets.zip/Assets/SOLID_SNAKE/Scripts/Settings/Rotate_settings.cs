using System.Collections;
using System.Collections.Generic;
using UnityEngine;
[CreateAssetMenu(menuName = "RorareSettings" , fileName = "Rotate/SettigsData")]
public class Rotate_settings : ScriptableObject
{
 [SerializeField][Range(0.0f,100.0f)]private float rotate_speed;

 public float Rotate_speed{get{return rotate_speed;}}
}
