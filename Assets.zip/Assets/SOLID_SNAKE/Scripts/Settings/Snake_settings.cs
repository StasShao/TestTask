using System.Collections;
using System.Collections.Generic;
using UnityEngine;
[CreateAssetMenu(menuName = "SnakeSettings", fileName = "Snake/SettingsData")]
public class Snake_settings : ScriptableObject
{
   [Header("Snake Move Speed")][SerializeField][Range(0.0f,1000.0f)]private float move_speed;
   [Header("Snake Strafe Speed")][SerializeField][Range(0.0f,100.0f)]private float strafe_speed;
   [Header("Snake brake force")][SerializeField][Range(0.0f,1000.0f)]private float tail_brake_force;

   public float Move_speed{get{return move_speed;}}
   public float Strafe_speed{get{return strafe_speed;}}
   public float Tail_brake_force{get{return tail_brake_force;}}
}
