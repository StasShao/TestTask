using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Tail_follow_main 
{
   public List<GameObject> _tail_objects;
   private Tail_follow _tai_fol;
   private GameObject _prefab;
   private Vector3 _offset;
   private float tail_scaler ;

   public  Tail_follow_main(List<GameObject> tail_objects, Vector3 offset,GameObject prefab,Tail_follow tai_fol)
   {
       this._tail_objects = tail_objects;
       this._offset = offset;
       this._prefab = prefab;
       this._tai_fol = tai_fol;
   }
   public void Start()
   {
     tail_scaler = _tail_objects[1].transform.localScale.x;
   }
   public void Follow()
   {
      
      _tail_objects[1].transform.position = Vector3.Slerp(_tail_objects[1].transform.position, _tail_objects[0].transform.position, 0.5f);
      _tail_objects[1].transform.LookAt(_tail_objects[0].transform.position);
      for(int i = 2;i<_tail_objects.Count;i++)
      {
        _tail_objects[i].transform.position = Vector3.Slerp(_tail_objects[i].transform.position, _tail_objects[i-1].transform.position, 0.2f) + _offset;
        _tail_objects[i].transform.LookAt(_tail_objects[i-1].transform.position);
       
      }
      
   }
   public void OnCollisionEnter(Collision col)
   {
       if(col.gameObject.tag == _tai_fol.gameObject.tag)
       {
         _tai_fol.Inst(); 
         if(_tail_objects[_tail_objects.Count -2].transform.localScale.x >= 0.2f)
         {
            tail_scaler = _tail_objects[_tail_objects.Count -2].transform.localScale.x - _tail_objects[_tail_objects.Count - 2].transform.localScale.x + 0.05f;
        _tail_objects[_tail_objects.Count -1].transform.localScale = new Vector3( _tail_objects[_tail_objects.Count -2].transform.localScale.x - tail_scaler,_tail_objects[_tail_objects.Count -2].transform.localScale.y - tail_scaler, _tail_objects[_tail_objects.Count -2].transform.localScale.z - tail_scaler);
         }
           if(_tail_objects[_tail_objects.Count -2].transform.localScale.x <= 0.2f)
           {
            _tail_objects[_tail_objects.Count -1].transform.localScale = new Vector3( _tail_objects[_tail_objects.Count -2].transform.localScale.x, _tail_objects[_tail_objects.Count -2].transform.localScale.y,_tail_objects[_tail_objects.Count -2].transform.localScale.z);
           }
       }
   }
}
