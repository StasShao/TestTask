using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Tail_follow : MonoBehaviour
{
    [Header("Need add 3 elements (Tails) in hierarchy placed")] 
    [Header("Before then")]
    [Header("Need add 1st element (Pvt_for_tail)")]
    // All enements count are - 4;
    [SerializeField]public List<GameObject> _tail_objects = new List<GameObject>();
    private Tail_follow_main tail_follo_main;
    [Header("Offset tails distance between all that elements")]
    [SerializeField]private Vector3 _offset;
    [Header("Tail prefab")]
    [SerializeField]private GameObject _prefab;
    void Start()
    {
        tail_follo_main = new Tail_follow_main(_tail_objects, _offset,_prefab,this);
        tail_follo_main.Start();
    }

    
    void FixedUpdate()
    {
        tail_follo_main.Follow();
        
    }
    void OnCollisionEnter(Collision col)
    {
        tail_follo_main.OnCollisionEnter(col);
       
    }
    public void Inst()
    {
       _tail_objects.Add(GameObject.Instantiate(_prefab,transform.position,transform.rotation) as GameObject);
       
      
    }
}
