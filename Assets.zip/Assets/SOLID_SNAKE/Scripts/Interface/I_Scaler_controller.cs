using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class I_Scaler_controller : I_scaler
{
    public float Curent_scale{get;private set;}

    public float Time{get;private set;}

    public bool Eat{get;private set;}

    public void Scale_change_minus()
    {
         Curent_scale -= 0.02f;
    }

    public void Scale_change_plus()
    {
       Curent_scale += 0.02f;
    }

    public void Scale_set()
    {
        Curent_scale = 1f;
    }

    public void SetOff()
    {
        Eat = false;
    }

    public void SetOn()
    {
        Eat = true;
    }

    public void Time_set()
    {
        Time = 0.03f;
    }
    
}
