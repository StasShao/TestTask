using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface I_controller
{
    bool Can_move{get;}
    float Z_move{get;}
    float H_move{get;}
    void ReadInput();
    void SpeedUp();
    void SpeedDown();
    void Left();
    void Right();
    void Zero();
    void Stop_move();
    void Start_move();
    
} 
public interface I_camera_follow
{
    float Follow_speed{get;}
    
}
public interface I_menu
{
    bool Exit{get;}
    void Finish();
  void ReadInput();
}
public interface I_score
{
    int Enemy_eat{get;}
    int Cristall_grab{get;}
    void Enemy();
    void Cristall();
    void CristallZero();
}
public interface I_Fever
{
   bool Fever_on{get;}

   void OnOff();
   void OffOn();
}
public interface I_scaler
{
   float Curent_scale{get;}
   float Time{get;}
   bool Eat{get;}
   void Scale_change_plus();
   void SetOff();
   void SetOn();
   void Scale_change_minus();
   void Time_set();
   void Scale_set();
}
public interface I_sound
{
    bool Hit{get;}
    bool Eat{get;}
    bool Cristall_take{get;}
    bool Burnout{get;}
   
    void _Hit();
    void _Eat();
    void _Cristall_take();
    void _Hit_false();
    void _Eat_false();
    void _Cristall_take_false();
    void Burnout_true();
    void Burnout_false();
   

}
public interface I_color
{
  int Color{get;}
  void Red();
  void Blue();
  void Yellow();
  void Green();
  void Purpur();
  void Light_blue();
}