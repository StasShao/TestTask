using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class I_player_controll : I_controller
{
    public float Z_move{get;private set;}

    public float H_move{get;private set;}

    public bool Can_move{get;private set;}

    public void ReadInput()
    {
        
        H_move = Mathf.Clamp(H_move, -85,85);
        
    }
    public void Left()
    {
        H_move -= 900f * Time.deltaTime;
    }

    public void Right()
    {
        H_move += 900 * Time.deltaTime;
    }

    public void SpeedDown()
    {
        Z_move = 1;
    }

    public void SpeedUp()
    {
        Z_move = Z_move * 1.003f;
    }

    public void Zero()
    {
       H_move = 0;
    }

    public void Stop_move()
    {
       Can_move = false;
    }

    public void Start_move()
    {
       Can_move = true;
    }
}
