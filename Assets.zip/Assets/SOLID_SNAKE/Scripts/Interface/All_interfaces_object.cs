using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class All_interfaces_object : MonoBehaviour
{
    public I_controller i_Controller;
    public I_camera_follow i_camera_follow;
    public I_menu I_menu;
    public I_score I_score;
    public I_Fever I_Fever;
    public I_scaler i_scaler;
    public I_sound i_sound;
    public I_color i_color;
   
    void Awake()
    {
        i_Controller = new I_player_controll();
        i_camera_follow = new Camera_i_face_controll();
        I_menu = new I_menu_input();
        I_score = new I_score_controller();
        I_Fever = new I_fever_controll();
        i_scaler = new I_Scaler_controller();
        i_sound = new I_sound_controller();
        i_color = new I_color_controller();
    }
 
 
}
