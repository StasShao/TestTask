using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Scnake_controller : MonoBehaviour
{
    private I_controller _i_controller;
    [SerializeField]private Item_prefab _item_prefab;
    [SerializeField]private Joystick _joystick;
    private Snake_controller_main snake_Controller_Main;
    [SerializeField]private Snake_settings _snake_settings;
    [SerializeField]private All_interfaces_object all_interfaces;
    
     public float _turn_speed;
    
    private Rigidbody rb;

  

    private void Start()
    {
        _i_controller = all_interfaces.i_Controller;
        snake_Controller_Main = new Snake_controller_main(gameObject,transform,_i_controller,_item_prefab,_snake_settings,rb,all_interfaces,_joystick);
        snake_Controller_Main.Start();
       
    }

    
     private void Update()
    {
      _i_controller.ReadInput();
      
    }
    private void FixedUpdate()
    {
       snake_Controller_Main.Tick();
    }
    public void SpeedUp()
    {
      _i_controller.SpeedUp();
    }
    public void SpeedDown()
    {
      _i_controller.SpeedDown();
    }
   
}
