using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Snake_controller_main 
{
    private GameObject _gameObject;
    private Joystick _joystick;
    private Transform _transform;
    private I_controller _i_controller;
    private Item_prefab _item_prefab;
    private Snake_settings _snake_settings;
    private All_interfaces_object _all_interfaces;
    private Rigidbody rb;
   
    private float max_angles;
    
    public Snake_controller_main(GameObject _gameObject,Transform _transform,I_controller _i_controller,Item_prefab item_prefab,Snake_settings snake_settings,Rigidbody rb,All_interfaces_object all_interfaces,Joystick joystick)
    {
      this._gameObject = _gameObject;
      this._transform = _transform;
      this._i_controller = _i_controller;
      this._item_prefab = item_prefab;
      this._snake_settings = snake_settings;
      this.rb = rb;
      this._all_interfaces = all_interfaces;
      this._joystick = joystick;
    }

    public void Start()
    {
      rb = GetFreeElement()._rb;
      _i_controller.SpeedDown();
    }

    public void Tick()
    {
       if(!_all_interfaces.I_Fever.Fever_on)
       {
          _item_prefab.gameObject.transform.eulerAngles = new Vector3(0,_i_controller.H_move * _joystick.Horizontal,0);
          if(_joystick.HandleRange < 0)
          {
            _all_interfaces.i_Controller.Left();
          }
          if(_joystick.HandleRange > 0)
          {
            _all_interfaces.i_Controller.Right();
          }
          if(_joystick.HandleRange == 0)
          {
            _all_interfaces.i_Controller.Zero();
          }
       }
         if(_all_interfaces.i_Controller.Can_move)
         {
            _item_prefab.gameObject.transform.position += _item_prefab.gameObject.transform.forward* _i_controller.Z_move *_snake_settings.Move_speed;
         }
        
        
    }
    public bool TryGetElement(Item_prefab element)
    {
        element.gameObject.SetActive(true);
        return true;
    }
    public Item_prefab GetFreeElement()
    {
        if(TryGetElement(_item_prefab))
        {
           return _item_prefab;
        }
      throw new System.Exception("Null object");
    }
}
