using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Camera_follow : MonoBehaviour
{
   [SerializeField]private GameObject _camera_go;
   [SerializeField]private Transform player_transform;
   [SerializeField]private All_interfaces_object all_interfaces;
   private I_camera_follow i_camera_follow;
   [SerializeField]private Camera_settings _camera_settings;
   private  Camera_main_script camera_Main_Script;
     
     private void Start()
    {
       i_camera_follow = all_interfaces.i_camera_follow;
        camera_Main_Script = new Camera_main_script(_camera_go,i_camera_follow,_camera_settings,player_transform);
    }

    
     private void LateUpdate()
    {
        camera_Main_Script.Follow_cam();
    }
}
