using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Camera_main_script 
{
   private GameObject _camera_go;
   private Transform _transform;
   private I_camera_follow _i_camera;
   private Camera_settings _camera_settings;

   public Camera_main_script(GameObject camera_go,I_camera_follow i_camera,Camera_settings camera_settings,Transform transform)
   {
      this._camera_go = camera_go;
      this._i_camera = i_camera;
      this._camera_settings = camera_settings;
      this._transform = transform;
   }
   public void Follow_cam()
   {
    _camera_go.transform.position = Vector3.Slerp(_camera_go.transform.position,_transform.position,_camera_settings.FollowSpeed * Time.deltaTime) + _camera_settings.Offset;
    _camera_go.transform.LookAt(_transform.position);
   }
}
