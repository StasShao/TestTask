using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Camera_i_face_controll : I_camera_follow
{
    public float Follow_speed{get;private set;}

   
}
