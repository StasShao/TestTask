using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Snake_color_inspector : MonoBehaviour
{
    private Color_inspector_main_script colorInspect;
    [SerializeField]private All_interfaces_object _all_interfaces_object;
    [Header("Snake tails material color change")]
    [SerializeField]private Material _material;

    [Header("Need to chose a purpur color")]
    [Header("Tthis is under development")]
    [SerializeField]private Color _purpur;

    [Header("Need to chose a light-blue color")]
    [Header("Tthis is under development")]
    [SerializeField]private Color _light_blue;
    
    
    void Start()
    {
        colorInspect = new Color_inspector_main_script(_all_interfaces_object,gameObject,_material,_purpur,_light_blue);
    }

    
    void FixedUpdate()
    {
        colorInspect.Inspect_color();
        
    }
}
