using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Color_inspector_main_script 
{
  private All_interfaces_object _all_interfaces_object;
  private GameObject _gameObject;
  private Material _material;
   private Color _purpur;
   private Color _light_blue;

  public Color_inspector_main_script(All_interfaces_object all_interfaces_object,GameObject gameObject,Material material,Color purpur,Color light_blue)
  {
    this._all_interfaces_object = all_interfaces_object;
    this._gameObject = gameObject; 
    this._material = material;
    this._purpur = purpur;
    this._light_blue = light_blue;
  }

  public void Inspect_color()
  {
      if(_all_interfaces_object.I_Fever.Fever_on == false)
      {
           if(_all_interfaces_object.i_color.Color == 0)
    {
       _gameObject.tag = "Blue";
       _material.color = Color.blue;
    }
    if(_all_interfaces_object.i_color.Color == 1)
    {
      _gameObject.tag = "Green";
       _material.color = Color.green;
    }
    if(_all_interfaces_object.i_color.Color == 2)
    {
        _gameObject.tag = "Light_blue";
       _material.color = _light_blue.gamma;
    }
    if(_all_interfaces_object.i_color.Color == 3)
    {
        _gameObject.tag = "Purpur";
       _material.color = _purpur.gamma;
    }
    if(_all_interfaces_object.i_color.Color == 4)
    {
        _gameObject.tag = "Red";
       _material.color = Color.red;
    }
    if(_all_interfaces_object.i_color.Color == 5)
    {
        _gameObject.tag = "Yellow";
       _material.color = Color.yellow;
    }

      }
     
   
  }
}
