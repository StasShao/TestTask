using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Snake_size_parametrs : MonoBehaviour
{
    [SerializeField]private All_interfaces_object all_Interfaces_Object;
    [Header("are eating")]
    [Header("to scale change when the snake")]
    [Header("Add tails elements what you want")]
    
    [SerializeField]public GameObject[] bodyes;
    private Scaler_main _scaler;
    private Size_item size_item;
    void Start()
    {
        _scaler = new Scaler_main(all_Interfaces_Object,this);
        all_Interfaces_Object.i_scaler.Scale_set();
        all_Interfaces_Object.i_scaler.Time_set();
    }
   
    private void Update()
    {
        _scaler.Settering();
    }
    public void Scale_ch()
    {
        
        StartCoroutine(_scaler.Scaler());
    }
    public void Eat_grabing()
    {
        _scaler.Eat_grab();
    }
}
