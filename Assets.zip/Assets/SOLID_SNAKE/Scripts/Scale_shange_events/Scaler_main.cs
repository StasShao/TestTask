using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Scaler_main 
{
  private All_interfaces_object _all_Interfaces_Object;
  private Snake_size_parametrs _snake_size_parametrs;

public Scaler_main(All_interfaces_object all_Interfaces_Object,Snake_size_parametrs snake_size_parametrs)
{
  this._all_Interfaces_Object = all_Interfaces_Object;
  this._snake_size_parametrs = snake_size_parametrs;
}
  public IEnumerator Scaler()
  // I can do it with another method use , for example --- for(int i = 0; i < _snake_size_parametrs.bodyes.Length;i++)
  // {_snake_size_parametrs.bodyes[i].transform.localScale = Vector3.Slerp(Vector3.a, Vector3.b, time); } but , my method Looking better in game play;
  // if will need , i can do it with another methods;
    {
        for(int i = 0;i < _snake_size_parametrs.bodyes.Length;i++)
        {
          
          _all_Interfaces_Object.i_scaler.Scale_change_plus();
          _snake_size_parametrs.bodyes[i].transform.localScale = new Vector3(_all_Interfaces_Object.i_scaler.Curent_scale,_all_Interfaces_Object.i_scaler.Curent_scale,_all_Interfaces_Object.i_scaler.Curent_scale);
           yield return new WaitForSeconds(_all_Interfaces_Object.i_scaler.Time);
          _all_Interfaces_Object.i_scaler.Scale_change_plus();
          _snake_size_parametrs.bodyes[i].transform.localScale = new Vector3(_all_Interfaces_Object.i_scaler.Curent_scale,_all_Interfaces_Object.i_scaler.Curent_scale,_all_Interfaces_Object.i_scaler.Curent_scale);
           yield return new WaitForSeconds(_all_Interfaces_Object.i_scaler.Time);
          _all_Interfaces_Object.i_scaler.Scale_change_plus();
          _snake_size_parametrs.bodyes[i].transform.localScale = new Vector3(_all_Interfaces_Object.i_scaler.Curent_scale,_all_Interfaces_Object.i_scaler.Curent_scale,_all_Interfaces_Object.i_scaler.Curent_scale);
           yield return new WaitForSeconds(_all_Interfaces_Object.i_scaler.Time);
          _all_Interfaces_Object.i_scaler.Scale_change_plus();
          _snake_size_parametrs.bodyes[i].transform.localScale = new Vector3(_all_Interfaces_Object.i_scaler.Curent_scale,_all_Interfaces_Object.i_scaler.Curent_scale,_all_Interfaces_Object.i_scaler.Curent_scale);
           yield return new WaitForSeconds(_all_Interfaces_Object.i_scaler.Time);
          _all_Interfaces_Object.i_scaler.Scale_change_plus();
          _snake_size_parametrs.bodyes[i].transform.localScale = new Vector3(_all_Interfaces_Object.i_scaler.Curent_scale,_all_Interfaces_Object.i_scaler.Curent_scale,_all_Interfaces_Object.i_scaler.Curent_scale);
           yield return new WaitForSeconds(_all_Interfaces_Object.i_scaler.Time);
          _all_Interfaces_Object.i_scaler.Scale_change_plus();
          _snake_size_parametrs.bodyes[i].transform.localScale = new Vector3(_all_Interfaces_Object.i_scaler.Curent_scale,_all_Interfaces_Object.i_scaler.Curent_scale,_all_Interfaces_Object.i_scaler.Curent_scale);
        }
        for(int i = 0;i< _snake_size_parametrs.bodyes.Length;i++)
        {
             
          _all_Interfaces_Object.i_scaler.Scale_change_minus();
          _snake_size_parametrs.bodyes[i].transform.localScale = new Vector3(_all_Interfaces_Object.i_scaler.Curent_scale,_all_Interfaces_Object.i_scaler.Curent_scale,_all_Interfaces_Object.i_scaler.Curent_scale);
             yield return new WaitForSeconds(_all_Interfaces_Object.i_scaler.Time);
          _all_Interfaces_Object.i_scaler.Scale_change_minus();
          _snake_size_parametrs.bodyes[i].transform.localScale = new Vector3(_all_Interfaces_Object.i_scaler.Curent_scale,_all_Interfaces_Object.i_scaler.Curent_scale,_all_Interfaces_Object.i_scaler.Curent_scale);
             yield return new WaitForSeconds(_all_Interfaces_Object.i_scaler.Time);
          _all_Interfaces_Object.i_scaler.Scale_change_minus();
          _snake_size_parametrs.bodyes[i].transform.localScale = new Vector3(_all_Interfaces_Object.i_scaler.Curent_scale,_all_Interfaces_Object.i_scaler.Curent_scale,_all_Interfaces_Object.i_scaler.Curent_scale);
             yield return new WaitForSeconds(_all_Interfaces_Object.i_scaler.Time);
          _all_Interfaces_Object.i_scaler.Scale_change_minus();
          _snake_size_parametrs.bodyes[i].transform.localScale = new Vector3(_all_Interfaces_Object.i_scaler.Curent_scale,_all_Interfaces_Object.i_scaler.Curent_scale,_all_Interfaces_Object.i_scaler.Curent_scale);
             yield return new WaitForSeconds(_all_Interfaces_Object.i_scaler.Time);
          _all_Interfaces_Object.i_scaler.Scale_change_minus();
          _snake_size_parametrs.bodyes[i].transform.localScale = new Vector3(_all_Interfaces_Object.i_scaler.Curent_scale,_all_Interfaces_Object.i_scaler.Curent_scale,_all_Interfaces_Object.i_scaler.Curent_scale);
             yield return new WaitForSeconds(_all_Interfaces_Object.i_scaler.Time);
          _all_Interfaces_Object.i_scaler.Scale_change_minus();
          _snake_size_parametrs.bodyes[i].transform.localScale = new Vector3(_all_Interfaces_Object.i_scaler.Curent_scale,_all_Interfaces_Object.i_scaler.Curent_scale,_all_Interfaces_Object.i_scaler.Curent_scale);
          
        }
       
    }
    public void Settering()
    {
        if(_snake_size_parametrs.gameObject.name == "Player")
        {
             if(_all_Interfaces_Object.i_scaler.Eat)
          {
            _snake_size_parametrs.Scale_ch();
            _all_Interfaces_Object.i_scaler.SetOff();
          }
        }
        
    }
    public void Eat_grab()
    {
      if(_snake_size_parametrs.gameObject.tag == "Red"||_snake_size_parametrs.gameObject.tag == "Blue"||_snake_size_parametrs.gameObject.tag == "Yellow"||_snake_size_parametrs.gameObject.tag == "Green")
        {
           _snake_size_parametrs.gameObject.transform.localScale =  Vector3.Slerp(_all_Interfaces_Object.gameObject.transform.localScale, new Vector3(0,0,0), 2 * Time.deltaTime);
        }
    }
}
