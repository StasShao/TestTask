using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Size_item : MonoBehaviour
{
    public GameObject go;
    public Size_item script;
    void Start()
    {
        
    }

   
    void Update()
    {
        
    }
    public void EatigThis()
    {
        
    }
}
