using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Inspector_main 
{
   private I_Fever _i_fev;
   private GameObject _snake;
   private GameObject _snake_body;
   private Snake_settings _settings;
   private BoxCollider box_col;
   private Scnake_controller _Scnake_controller;
   private All_interfaces_object _all_interfaces;
   private Material _material;
    public bool _fever_on;
    public bool _test;
    private float timer = 0f;
    

    public Inspector_main(I_Fever i_fev,bool fever_on,GameObject snake,Snake_settings settings,Scnake_controller Scnake_controller,BoxCollider box_col,All_interfaces_object all_interfaces,Material material,GameObject snake_body)
    {
       this._i_fev = i_fev;
       this._fever_on = fever_on;
       this._snake = snake;
       this._settings = settings;
       this._Scnake_controller = Scnake_controller;
       this.box_col = box_col;
       this._all_interfaces = all_interfaces;
       this._material = material;
       this._snake_body = snake_body;
    }
    public Inspector_main(bool test)
    {
      this._test = test;
    }
   
    public void Update()
    {
        
       
          if(_all_interfaces.I_Fever.Fever_on)
          {
              Snake_faver();
              timer += 0.1f*Time.deltaTime;
              if(timer >= 0.3f)
              {
                  _all_interfaces.I_Fever.OffOn();
                  _all_interfaces.i_Controller.SpeedDown();
                  timer = 0f;
              }
          }
       if(_all_interfaces.I_Fever.Fever_on == false)
       {
           
           if(_all_interfaces.i_color.Color == 0)
           {
               _snake.tag = "Blue";
           }
            if(_all_interfaces.i_color.Color == 5)
           {
               _snake.tag = "Yellow";
           }
            if(_all_interfaces.i_color.Color == 4)
           {
               _snake.tag = "Red";
           }
            if(_all_interfaces.i_color.Color == 1)
           {
               _snake.tag = "Green";
           }
            if(_all_interfaces.i_color.Color == 3)
           {
               _snake.tag = "Purpur";
           }
            if(_all_interfaces.i_color.Color == 2)
           {
               _snake.tag = "Light_blue";
           }
           
       }
    }
    public void Fever_on()
    {
      _fever_on = true;
    }
    public void Fever_off()
    {
       _fever_on = false;  
    }
    public void Snake_faver()
    {
        _snake.transform.position = new Vector3(0,_snake.transform.position.y,_snake.transform.position.z);
        _snake.transform.rotation = new Quaternion(0,0,0,0);
        _snake.tag = "Faver";
        _Scnake_controller.SpeedUp();
    }
}
