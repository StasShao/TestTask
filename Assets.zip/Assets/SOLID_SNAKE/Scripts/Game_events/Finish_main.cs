using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Finish_main 
{
  private All_interfaces_object _all_interface_object;
  private GameObject _youWin;
  private GameObject _best_finish_score;

  public Finish_main(All_interfaces_object all_interface_object,GameObject youWin,GameObject best_finish_score)
  {
     this._all_interface_object = all_interface_object;
     this._youWin = youWin;
     this._best_finish_score = best_finish_score;
  }
   public void OnTriggerEnter(Collider col)
   {
       if(col.name == "Player")
       {
         _all_interface_object.I_menu.Finish();
         _youWin.SetActive(true);
         _best_finish_score.SetActive(true);
       }
   }
}
