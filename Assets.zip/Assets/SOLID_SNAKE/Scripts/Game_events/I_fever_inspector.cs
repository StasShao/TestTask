using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class I_fever_inspector : MonoBehaviour
{
    private Inspector_main inspector_main;
    [SerializeField]private GameObject snake;
    [SerializeField]private GameObject _snake_body;
    [SerializeField]private Snake_settings _settings;
    [SerializeField]private Scnake_controller _Scnake_controller;
    [SerializeField]private BoxCollider box_col;
    [SerializeField]private All_interfaces_object all_interfaces;
    [SerializeField]private Material _material;
    public I_Fever i_fev;
    public bool fever_on;
   
    
    
    void Start()
    {
        i_fev = all_interfaces.I_Fever;
        inspector_main = new Inspector_main(i_fev,fever_on,snake,_settings,_Scnake_controller,box_col,all_interfaces,_material,_snake_body);
        
    }

    
    void Update()
    {
        inspector_main.Update();
    }
    public void FeverOn()
    {
      inspector_main.Fever_on();
    }
    public void FeverOff()
    {
        inspector_main.Fever_off();
    }
}
