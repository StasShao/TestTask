using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class I_fever_controll : I_Fever
{
    public bool Fever_on{get;private set;}
 
    public void OnOff()
    {
        Fever_on = true;
    }

    public void OffOn()
    {
        Fever_on = false;
    }
}
