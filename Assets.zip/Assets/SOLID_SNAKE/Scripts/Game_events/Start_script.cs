using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Start_script : MonoBehaviour
{
    [SerializeField]private All_interfaces_object _all_interfaces_object;
    

    private void Start()
    {
       
        _all_interfaces_object.i_Controller.Stop_move();
    }

   
}
