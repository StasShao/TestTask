using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Finish : MonoBehaviour
{
    private Finish_main finish_main;
    [SerializeField]private GameObject _youWin;
    [SerializeField]private All_interfaces_object all_Interfaces_Object;
    [SerializeField]private GameObject _best_finish_score;

    private void Start()
    {
        finish_main = new Finish_main(all_Interfaces_Object,_youWin,_best_finish_score);
    }
    private void OnTriggerEnter(Collider col)
    {
        finish_main.OnTriggerEnter(col);
    }
}
