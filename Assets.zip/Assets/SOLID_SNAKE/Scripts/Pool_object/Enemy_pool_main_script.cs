using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy_pool_main_script 
{
   private List<Item_script> _pool;
   private GameObject _gameObject;
   private Transform _container;
   private Enemy_pool _enemy_pool;
   private int _min_capacity;
    private int _max_capacity;
    private bool _autoExpand;

     public Enemy_pool_main_script(List<Item_script> pool,Transform container,Enemy_pool enemy_pool,int min_capacity,int max_capacity,bool autoExpand)
     {
        this._pool = pool;
        this._container = container;
        this._enemy_pool = enemy_pool;
        this._min_capacity = min_capacity;
        this._max_capacity = max_capacity;
        this._autoExpand = autoExpand;
     }
     public void Start()
     {
         CreatePool();
         
         for(int i = 0; i < _pool.Count; i++)
         {
             _gameObject = GetFreeElement().go;
            _gameObject.transform.position = new Vector3(Random.Range(-6f,6f),0,_gameObject.transform.position.z + i * 2.2f);
         }
        
     }
     
      private void CreatePool()
    {
        
        
        for(int i = 0; i < _min_capacity;i++)
        {
           _enemy_pool.CreateElement();
                  
        }
    }
      public bool TryGetElement(out Item_script element)
    {
        foreach(var item in _pool)
        {
           
          if(!item.gameObject.activeInHierarchy)
          {
              element = item;
              item.gameObject.SetActive(true);
              
              return true;
              
          }
         if(item.gameObject.transform.localPosition.z >= 960 || item.gameObject.transform.localPosition.z <= -5)
              {
                  item.gameObject.SetActive(false);
              }
            
        
        }
         element = null;
          return false;
    }
    public Item_script GetFreeElement(Vector2 position, Quaternion rotation)
    {
         var element = GetFreeElement(position);
         element.transform.rotation = rotation;
         return element;
    }
    public Item_script GetFreeElement(Vector2 position)
    {
        var element = GetFreeElement();
        element.transform.position = position;
        return element;
    }
   
    public Item_script GetFreeElement()
    {
        if(TryGetElement(out var element))
        {
            return element; 
        }
        if(_autoExpand)
        {
            return _enemy_pool.CreateElement(true);
        }
        if(_pool.Count < _max_capacity)
        {
            return _enemy_pool.CreateElement(true);
        }
        
        throw new System.Exception("Pool is over");
    }
}
