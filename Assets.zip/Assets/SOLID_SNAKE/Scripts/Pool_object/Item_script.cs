using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Item_script : MonoBehaviour
{
    [SerializeField]private Material[] materials;
    public MeshRenderer material;
    [SerializeField]private MeshRenderer[] mesh;
    [SerializeField]private Color purpur;
    [SerializeField]private Color light_blue;
    private int random_color;
    public GameObject go;

    private void Start()
    {
        random_color = Random.Range(0,6);
        if(random_color != Random.Range(0,6))
        {
              foreach(MeshRenderer item in mesh)
             {
               item.material.color = Color.green;
               item.gameObject.tag = "Green";
             }
        }
         if(random_color == 0)
          {
           foreach(MeshRenderer item in mesh)
             {
               item.material.color = Color.green;
               item.gameObject.tag = "Green";
             }
          }
              if(random_color == 1)
            {
                 foreach(MeshRenderer item in mesh)
                {
                item.material.color = Color.yellow;
                item.gameObject.tag = "Yellow";
                }
            }
             if(random_color == 2)
            {
              foreach(MeshRenderer item in mesh)
             {
              item.material.color = Color.red;
              item.gameObject.tag = "Red";
             }
            }
             if(random_color == 3)
             {
              foreach(MeshRenderer item in mesh)
              {
                item.material.color = Color.blue;
                item.gameObject.tag = "Blue";
              }
             }
              if(random_color == 4)
             {
              foreach(MeshRenderer item in mesh)
              {
                item.material.color = purpur.gamma;
                item.gameObject.tag = "Purpur";
              }
             }
              if(random_color == 5)
             {
              foreach(MeshRenderer item in mesh)
              {
                item.material.color = light_blue.gamma;
                item.gameObject.tag = "Light_blue";
              }
             }

     
     }
       
}
