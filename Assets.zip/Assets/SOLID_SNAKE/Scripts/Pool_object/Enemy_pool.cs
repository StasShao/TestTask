using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy_pool : MonoBehaviour
{
    private List<Item_script> _pool;

    [Header("Chose prefabs whith (Item_script)")]
    [SerializeField]private Item_script[] _prefab;
    private Item_script created_O;
    private Enemy_pool_main_script enemy_pool_main_script;
    [Header("Place parent of that prefabs")]
    [Space(10)][SerializeField]public Transform _container;
    [Header("Minimum number of prefabs")]
    [SerializeField][Range(0,1000)] private int _min_capacity;
    [Header("Maximum number of prefabs to expand")]
    [SerializeField][Range(0,1000)]private int _max_capacity;
    [Header("Expand to maximum number")]
    public bool _autoExpand;
    void Start()
    {
        _pool = new List<Item_script>();
        enemy_pool_main_script = new Enemy_pool_main_script(_pool,_container,this,_min_capacity,_max_capacity,_autoExpand);
        enemy_pool_main_script.Start();
    }
     public void OnValidate()
      {
       if(_autoExpand)
        {
            _max_capacity = int.MaxValue;
        }
      }
    
   
    public Item_script CreateElement(bool isActiveByDefault = false)
    {
        
        foreach(Item_script item in _prefab)
        {
            Item_script createdObject = Instantiate(item,_container);
             createdObject.gameObject.SetActive(isActiveByDefault);
        _pool.Add(createdObject);
        
        created_O = createdObject;
        }
        return created_O;
         
    }
}
