using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Score : MonoBehaviour
{
    private Score_main_script score_main_script;
   [SerializeField]private Text food_score_menu;
   [SerializeField]private Text _food_score_finish;
   [SerializeField]private Text cristall_score_menu;
   [SerializeField]private Text best_food_score_menu;
   [SerializeField]private Text best_cristall_score_menu;
   [SerializeField]private All_interfaces_object all_interfaces;
   

   public int food_score;
   public int cristall_score;
   public int best_food_sore;
   public int best_cristall_sore;
    
   private void Start()
   {
      
      score_main_script = new Score_main_script(food_score_menu,cristall_score_menu,food_score,cristall_score,best_food_sore,best_cristall_sore,best_food_score_menu,best_cristall_score_menu,all_interfaces,_food_score_finish);
      score_main_script.LoadProgress();
   }
   private void Update()
   {
      
    score_main_script.Tick();
   }
}
