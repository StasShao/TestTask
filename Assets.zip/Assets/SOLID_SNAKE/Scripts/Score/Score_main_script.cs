using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Score_main_script 
{
   private Collision_main_script col_main;
   
   private All_interfaces_object _all_interfaces;
   private Text _food_score_menu;
   private Text _food_score_finish;
   private Text _cristall_score_menu;
    private Text _best_food_score_menu;
   private Text _best_cristall_score_menu;
   private int _food_score;
   private int _cristall_score;
   private int _best_food_sore;
   private int _best_cristall_sore;
   public Score_main_script(Text food_score_menu,Text cristall_score_menu,int food_score,int cristall_score,int best_food_sore,int best_cristall_sore,Text best_food_score_menu,Text best_cristall_score_menu,All_interfaces_object all_interfaces,Text food_score_finish)
   {
    this._food_score_menu = food_score_menu;
    this._cristall_score_menu = cristall_score_menu;
    this._food_score = food_score;
    this._cristall_score = cristall_score;
    this._food_score_finish = food_score_finish;
    this._best_food_sore = best_food_sore;
    this._best_cristall_sore = best_cristall_sore;
    this._best_food_score_menu = best_food_score_menu;
    this._best_cristall_score_menu = best_cristall_score_menu;
    this._all_interfaces = all_interfaces;
   }
  public void Tick()
  {
    
       _food_score = _all_interfaces.I_score.Enemy_eat;
      _cristall_score = _all_interfaces.I_score.Cristall_grab; 
      _food_score_finish.text = _food_score.ToString();
      _best_food_score_menu.text = _best_food_sore.ToString();
      
     _food_score_menu.text = _food_score.ToString();
     _cristall_score_menu.text = _cristall_score.ToString();
     if(_cristall_score >= 3)
     {
       _all_interfaces.I_score.CristallZero();
     }
     if(_food_score >= _best_food_sore)
     {
         _best_food_sore = _food_score;
        SaveProgress();
     }
     if(_cristall_score >= _best_cristall_sore)
     {
         _best_cristall_sore = _cristall_score;
         SaveProgress();
     }
  }
  private void SaveProgress()
  {
     PlayerPrefs.SetInt("SaveFoodScore", _best_food_sore);
    
  }
  public void LoadProgress()
  {
      if(PlayerPrefs.HasKey("SaveFoodScore"))
      {
        _best_food_sore = PlayerPrefs.GetInt("SaveFoodScore", _best_food_sore);
        
      }
     
  }

}
