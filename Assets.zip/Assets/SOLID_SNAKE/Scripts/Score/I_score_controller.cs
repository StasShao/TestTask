using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class I_score_controller : I_score
{
    public int Enemy_eat{get;private set;}

    public int Cristall_grab{get;private set;}

    public void Cristall()
    {
         Cristall_grab ++;
    }

    public void CristallZero()
    {
        Cristall_grab = 0;
    }

    public void Enemy()
    {
       Enemy_eat ++;
    }
}
