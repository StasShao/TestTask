using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Rotate_object : MonoBehaviour
{
    [SerializeField]private Rotate_settings _rotate_settings;
    private Rotate_object_main rotate_object_main;
    void Start()
    {
        rotate_object_main = new Rotate_object_main(transform,_rotate_settings);
    }

    
    void Update()
    {
        rotate_object_main.Rotate_object();
    }
}
