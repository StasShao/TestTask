using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Rotate_object_main 
{
   private Transform _go_transform;
   private Rotate_settings _rotate_settings;
   
  public Rotate_object_main(Transform go_transform,Rotate_settings rotate_settings)
  {
    this._go_transform = go_transform;
    this._rotate_settings = rotate_settings;
  }

   public void Rotate_object()
   {
       _go_transform.eulerAngles += new Vector3(0,_rotate_settings.Rotate_speed,0);
   } 
}
