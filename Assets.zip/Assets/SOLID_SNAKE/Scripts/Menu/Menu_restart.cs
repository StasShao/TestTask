using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class Menu_restart 
{
    private GameObject _button_restart;
    private GameObject _button_exit;
    private GameObject _game_over_button;
    private GameObject _joystick; 
    private Text _text_over;
    private GameObject _player;
    private I_menu _i_menu;
    
    private All_interfaces_object _all_interface_object;
   
   public Menu_restart(GameObject button_restart,GameObject game_over_button,I_menu i_menu,GameObject button_exit,GameObject player,Text text_over,All_interfaces_object all_interface_object,GameObject joystick)
   {
     this._button_restart = button_restart;
     this._game_over_button = game_over_button;
     this._i_menu = i_menu;
     this._button_exit = button_exit;
     this._player = player;
     this._text_over = text_over;
     this._all_interface_object = all_interface_object;
     this._joystick = joystick;
   }
     public void Restart()
   {
      _game_over_button.SetActive(false);
      SceneManager.LoadScene("SampleScene");
   }
   public void ButtonRestart()
   {
     if(_all_interface_object.I_menu.Exit == true)
     {
      Time.timeScale = 0.01f;
       _button_restart.SetActive(true);
       _button_exit.SetActive(true);
     }else if(_all_interface_object.I_menu.Exit == false)
     {
       Time.timeScale = Mathf.Lerp(0.2f,1.0f,2f);
        _button_restart.SetActive(false);
        _button_exit.SetActive(false);
     }
      
       
         if(_player.activeSelf == false)
          {
            _text_over.enabled = true;
           _joystick.SetActive(false);
            _button_restart.SetActive(true);
           _button_exit.SetActive(true);
          }
          if(_player.activeSelf == true)
          {
            _text_over.enabled = false;
            _joystick.SetActive(true);
          }
       
   }
   public void Exit()
   {
       Application.Quit();
   }
}
