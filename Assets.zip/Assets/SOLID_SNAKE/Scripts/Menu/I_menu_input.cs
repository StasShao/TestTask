using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class I_menu_input : I_menu
{
    public bool Exit{get;private set;}

    public void Finish()
    {
       Exit = true;
    }

    public void ReadInput()
    {
        if(Exit == true)
        {
          if(Input.GetKeyDown(KeyCode.Escape))
          {
             Exit = false;
          }
        }else if(Input.GetKeyDown(KeyCode.Escape))
        {
            Exit = true;
        }
    }
}
