using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Menu_script : MonoBehaviour
{
    [SerializeField]private GameObject _joystick;
    [SerializeField]private GameObject _button_restart;
    [SerializeField]private GameObject _game_over_button;
    [SerializeField]private GameObject _button_exit;
    [SerializeField]private GameObject _button_ready; 
    [SerializeField]private GameObject _player;
    [SerializeField]private Text _text_over;
    [SerializeField]private All_interfaces_object all_interfaces;
    private Menu_restart menu_Restart;
     private I_menu _i_menu;

   
    void Start()
    {
        _i_menu = all_interfaces.I_menu;
        menu_Restart = new Menu_restart(_button_restart,_game_over_button,_i_menu,_button_exit,_player,_text_over,all_interfaces,_joystick);
    }

    void Update()
    {
        _i_menu.ReadInput();
         menu_Restart.ButtonRestart();
    }
    public void Rest()
    {
        menu_Restart.Restart();
       
        
    }
    public void Ext()
    {
        menu_Restart.Exit();
    }
    public void Ready()
    {
         all_interfaces.i_Controller.Start_move();
        _button_ready.SetActive(false);
    }
}
