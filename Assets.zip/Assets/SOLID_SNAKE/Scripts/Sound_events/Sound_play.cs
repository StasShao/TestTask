using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Sound_play : MonoBehaviour
{
    [SerializeField]private All_interfaces_object all_Interfaces_Object;
    [SerializeField]private AudioSource a_surce;
    [SerializeField]private AudioClip[] a_clips;
    private Sound_main sound_main;
    
    void Start()
    {
        sound_main = new Sound_main(a_surce,a_clips,all_Interfaces_Object);
    }

    
    void Update()
    {
        sound_main.Tick();
    }
}
