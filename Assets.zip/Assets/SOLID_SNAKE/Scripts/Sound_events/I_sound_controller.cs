using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class I_sound_controller : I_sound
{
    public bool Hit{get;private set;} 

    public bool Eat{get;private set;}

    public bool Cristall_take{get;private set;}

    public bool Burnout{get;private set;}

    public void Burnout_false()
    {
        Burnout = false;
    }

    public void Burnout_true()
    {
        Burnout = true;
    }

    public void _Cristall_take()
    {
        Cristall_take = true;
    }

    public void _Cristall_take_false()
    {
        Cristall_take = false;
    }

    public void _Eat()
    {
        Eat = true;
    }

    public void _Eat_false()
    {
        Eat = false;
    }

    public void _Hit()
    {
        
        Hit = true;
    }

    public void _Hit_false()
    {
        Hit = false;
    }
}
