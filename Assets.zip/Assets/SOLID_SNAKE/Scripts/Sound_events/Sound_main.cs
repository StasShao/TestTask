using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Sound_main 
{
   private AudioSource _a_source;
   private AudioClip[] _a_clips;
   private All_interfaces_object _all_interface_object;
   
   public Sound_main(AudioSource a_source,AudioClip[] a_clips,All_interfaces_object all_interface_object)
   {
     this._a_source = a_source;
     this._a_clips = a_clips;
     this._all_interface_object = all_interface_object;
   }
   public void Tick()
   {
       if(_all_interface_object.i_sound.Eat)
       {
         _a_source.clip = _a_clips[0];
         _a_source.PlayOneShot(_a_clips[0]);
         _all_interface_object.i_sound._Eat_false();
       }
       if(_all_interface_object.i_sound.Hit)
       {
           _a_source.clip = _a_clips[1];
         _a_source.PlayOneShot(_a_clips[1]);
         _all_interface_object.i_sound._Hit_false();
       }
       if(_all_interface_object.i_sound.Cristall_take)
       {
           _a_source.clip = _a_clips[2];
         _a_source.PlayOneShot(_a_clips[2]);
         _all_interface_object.i_sound._Cristall_take_false();
       }
        if(_all_interface_object.i_sound.Burnout)
       {
           _a_source.clip = _a_clips[3];
         _a_source.PlayOneShot(_a_clips[3]);
         _all_interface_object.i_sound.Burnout_false();
       }
      
   }
  
}
