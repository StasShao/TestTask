using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class I_color_controller : I_color
{
    public int Color{get;private set;}

    public void Blue()
    {
        Color = 0;
    }

    public void Green()
    {
        Color = 1;
    }

    public void Light_blue()
    {
        Color = 2;
    }

    public void Purpur()
    {
        Color = 3;
    }

    public void Red()
    {
        Color = 4;
    }

    public void Yellow()
    {
        Color = 5;
    }
}
