using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Color_check_points_main 
{
   private GameObject _gameObject;
   private Material _material;
   private Color _purpur;
   private Color _light_blue;
   private All_interfaces_object _all_interfaces_object;

  public Color_check_points_main(GameObject gameObject,Material material,Color purpur,Color light_blue,All_interfaces_object all_interfaces_object)
  {
      this._gameObject = gameObject;
      this._material = material;
      this._purpur = purpur;
      this._light_blue = light_blue;
      this._all_interfaces_object = all_interfaces_object;
  }
   public void OnTriggerEnter(Collider col)
   {
       if(_gameObject.tag == "Green_check")
       {
           if(col.name == "Player")
          {
            _all_interfaces_object.i_color.Green();
           
          }
       }
       
       if(_gameObject.tag == "Red_check")
       {
           if(col.name == "Player")
          {
           _all_interfaces_object.i_color.Red();
          }
       }
       if(_gameObject.tag == "Blue_check")
       {
           if(col.name == "Player")
          {
           _all_interfaces_object.i_color.Blue();
          }
       }
       if(_gameObject.tag == "Yellow_check")
       {
           if(col.name == "Player")
          {
           _all_interfaces_object.i_color.Yellow();
          }
       }
       if(_gameObject.tag == "Purpur_check")
       {
          if(col.name == "Player")
          {
            _all_interfaces_object.i_color.Purpur();
          }
       }
        if(_gameObject.tag == "Light_blue_check")
       {
           if(col.name == "Player")
          {
            _all_interfaces_object.i_color.Light_blue();
          }
       }
      
   }
  
}
