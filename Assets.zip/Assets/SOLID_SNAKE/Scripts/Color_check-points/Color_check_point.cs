using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Color_check_point : MonoBehaviour
{
    [SerializeField]private Material _material;
    private Color_check_points_main color_check_points_main;
     [SerializeField]private All_interfaces_object _all_interfaces_object;
    [SerializeField]private Color _purpur;
    [SerializeField]private Color _light_blue;
  

   private void Awake()
   {
     color_check_points_main = new Color_check_points_main(gameObject,_material,_purpur,_light_blue,_all_interfaces_object);
   }

   private void OnTriggerEnter(Collider col)
   {
       color_check_points_main.OnTriggerEnter(col);
   }
}
