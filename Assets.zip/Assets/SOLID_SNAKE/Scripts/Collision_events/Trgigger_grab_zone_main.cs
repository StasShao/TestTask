using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Trgigger_grab_zone_main 
{
    private Transform _transform;
    private Vector3 pos;
    private bool eat;
    public Trgigger_grab_zone_main(Transform transform)
    {
        this._transform = transform;
    }
  public void OnTriggerEnter(Collider col)
  {
      if(col.tag == "Eat_zone")
      {
        eat = true;
        pos = col.transform.position;
      }
  }
  public void Eating()
  {
      if(eat)
      {
         float positionX = pos.x;
         float positionZ = pos.z;
        _transform.localScale = Vector3.Slerp(_transform.localScale, new Vector3(0,0,0),3 * Time.deltaTime);
        _transform.position = Vector3.Slerp(_transform.position, new Vector3(positionX,_transform.position.y,positionZ), 2 * Time.deltaTime);
      }
  }
}
