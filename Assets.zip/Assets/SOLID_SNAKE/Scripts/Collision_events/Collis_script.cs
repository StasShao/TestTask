using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Collis_script : MonoBehaviour
{
   
     private Collision_main_script col_script;
     
     [SerializeField]private All_interfaces_object all_interfaces;
     
    
    private bool on;
   
    private void Start()
    {
      col_script = new Collision_main_script(gameObject,this,all_interfaces);
    }
     private void OnCollisionEnter(Collision col)
    {
      col_script.OnCollisionEnter(col);
    }
    
     private void Update()
     {
        col_script.Update();
     }
}
