using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Trigger_grab : MonoBehaviour
{
    private Trgigger_grab_zone_main trgigger_Grab_Zone_Main;
    [SerializeField]private Transform _transform;
    
    private void Awake()
    {
        trgigger_Grab_Zone_Main = new Trgigger_grab_zone_main(_transform);
    }
      public void OnTriggerEnter(Collider col)
     {
        trgigger_Grab_Zone_Main.OnTriggerEnter(col);
     }
       private void Update()
      {
        trgigger_Grab_Zone_Main.Eating();
      }

}
