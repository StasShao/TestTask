using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Collision_main_script 
{
    private GameObject go;
    private Material _material;
    private int cristalls;
    private Collis_script _collis_Script;
    private All_interfaces_object _all_interfaces;
    
   
      
    public Collision_main_script(GameObject gameObject, Collis_script collis_Script,All_interfaces_object all_interfaces)
    {
       this.go = gameObject;
      
       this._collis_Script = collis_Script;
      
       this._all_interfaces = all_interfaces;
    }
      public void Update()
   {
     if(cristalls >=3)
     {
       _all_interfaces.I_Fever.OnOff();
       _all_interfaces.i_sound.Burnout_true();
       cristalls = 0;
     }
   
   }
  public void OnCollisionEnter(Collision col)
  {
    if(go.tag == "Faver")
    {
      if(col.gameObject.tag != "Wall")
      {
        col.gameObject.SetActive(false);
        _all_interfaces.i_sound._Eat();
      }
      if(col.gameObject.tag == "Red"||col.gameObject.tag == "Blue"||col.gameObject.tag == "Yellow"||col.gameObject.tag == "Green"||col.gameObject.tag == "Purpur"||col.gameObject.tag == "Light_blue")
      {
        _all_interfaces.I_score.Enemy();
        _all_interfaces.i_sound._Eat();
        _all_interfaces.i_scaler.SetOn();
      }
       if(col.gameObject.tag == "Cristall")
      {
        _all_interfaces.I_score.Cristall();
        _all_interfaces.i_sound._Cristall_take();
      }
      return;
    }
   

      if(col.gameObject.tag == "Cristall")
      {
        _all_interfaces.I_score.Cristall();
        _all_interfaces.i_sound._Cristall_take();
        cristalls ++;

       
        col.gameObject.SetActive(false);
      }
      if(col.gameObject.tag == go.tag)
      {
        _all_interfaces.I_score.Enemy();
        _all_interfaces.i_sound._Eat();
        col.gameObject.SetActive(false);
        _all_interfaces.i_scaler.SetOn();
      }else if(col.gameObject.tag != go.tag && col.gameObject.tag != "Wall"&& col.gameObject.tag != "Cristall"){go.SetActive(false);_all_interfaces.i_sound._Hit();}
      if(col.gameObject.tag == "Obst")
      {
          go.SetActive(false);
      }
  }
  
  
}
